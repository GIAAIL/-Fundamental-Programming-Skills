#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
	char S[5], G[5];
	gets_s(S);

	bool seen[10] = { false };
	for (int i = 0; i < 4; i++) {
		seen[S[i] - '0'] = true;
	}

	while (true) {
		gets_s(G);
		int A = 0, B = 0;
		for (int i = 0; i < 4; i++) {
			if (S[i] == G[i]) A++;
			else if (seen[G[i] - '0']) B++;
		}

		printf("%dA%dB\n", A, B);
		if (A == 4) break;
	}
}