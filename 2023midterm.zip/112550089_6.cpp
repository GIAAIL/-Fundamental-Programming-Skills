#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

bool aboutEqual(float a, float b) {
	return fabs(a - b) <= 1e-12;
}

int main()
{
	float W, H, dx, dy, Cx, Cy, Tx, Ty;
	scanf("%f %f %f %f %f %f %f %f", &W, &H, &dx, &dy, &Cx, &Cy, &Tx, &Ty);

	int ans = 0;
	while (ans <= 1000) {
		// Target Ball collision test
		float xTimeReq = (Tx - Cx) / dx;
		float yTimeReq = (Ty - Cy) / dy;
		if (xTimeReq >= 0 && aboutEqual(xTimeReq, yTimeReq)) break;

		// Wall collision test
		if (dx < 0) xTimeReq = (0 - Cx) / dx;
		else if (dx > 0) xTimeReq = (W - Cx) / dx;
		else xTimeReq = INFINITY;

		if (dy < 0) yTimeReq = (0 - Cy) / dy;
		else if (dy > 0) yTimeReq = (H - Cy) / dy;
		else yTimeReq = INFINITY;

		if (xTimeReq == INFINITY && yTimeReq == INFINITY) {
			ans = -1;
			break;
		}
		else if (aboutEqual(xTimeReq, yTimeReq)) {
			Cx += dx * xTimeReq;
			dx *= -1;
			Cy += dy * yTimeReq;
			dy *= -1;
		}
		else if (xTimeReq > yTimeReq) {
			Cx += dx * yTimeReq;
			Cy += dy * yTimeReq;
			dy *= -1;
		}
		else if (xTimeReq < yTimeReq) {
			Cx += dx * xTimeReq;
			dx *= -1;
			Cy += dy * xTimeReq;
		}

		ans++;
	}

	if (ans > 1000) ans = -1;
	printf("%d\n", ans);
}