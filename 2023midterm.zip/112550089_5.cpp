#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// req[A][B] is true if crafting A requires B
bool req[26][26] = { false };
int memo[26];

int calcReqFor(int item) {
	if (memo[item] != -1) return memo[item];
	int ret = 0;
	for (int i = 0; i < 26; i++) {
		if (req[item][i]) ret += calcReqFor(i);
	}
	memo[item] = ret;
	return ret;
}

int main()
{
	for (int i = 0; i < 26; i++) memo[i] = -1;

	int N;
	scanf("%d", &N);

	for (int i = 0; i < N; i++) {
		int M;
		scanf("%d", &M);
		if (M == 0) {
			memo[i] = 1;
		}
		else {
			char inp[64];
			inp[0] = '\0';
			while (strlen(inp) == 0) gets_s(inp);

			for (int k = 0; k < M; k++) {
				req[i][inp[2 * k] - 'a'] = true;
			}
		}
	}

	int ans = 0;
	for (int i = 0; i < N; i++) ans += calcReqFor(i);
	printf("%d\n", ans);
}