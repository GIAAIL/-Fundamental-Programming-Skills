#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define MIN(x, y) (x < y ? x : y)

bool isPrime(int n) {
	int testMax = MIN(n, sqrt(n) + 42);
	for (int i = 2; i < testMax; i++) {
		if (n % i == 0) return false;
	}
	return true;
}

int main()
{
	int n;
	scanf("%d", &n);

	int dist = 0;
	while (true) {
		if (isPrime(n - dist)) {
			printf("%d\n", n - dist);
			return 0;
		}
		else if (isPrime(n + dist)) {
			printf("%d\n", n + dist);
			return 0;
		}
		dist++;
	}
}