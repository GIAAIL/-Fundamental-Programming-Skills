#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

long long origMat[100][100];
long long ans[100];
long double mat[100][100];
int H, W;

void op1_exchangeRows(int a, int b) {
	for (int i = 0; i < W; i++) {
		long double tmp = mat[a][i];
		mat[a][i] = mat[b][i];
		mat[b][i] = tmp;
	}
}

void op2_scalarMult(int row, long double mult) {
	for (int i = 0; i < W; i++) {
		mat[row][i] *= mult;
	}
}

void op3_multAndAdd(int from, int into, long double mult) {
	for (int i = 0; i < W; i++) {
		mat[into][i] += mat[from][i] * mult;
	}
}

bool solve() {
	for (int i = 0; i < H; i++) {
		if (mat[i][i] == 0) {
			for (int k = i + 1; k < H; k++) {
				if (mat[k][i] != 0) {
					op1_exchangeRows(i, k);
					break;
				}
			}
		}

		op2_scalarMult(i, 1 / mat[i][i]);
		for (int k = i + 1; k < H; k++) {
			op3_multAndAdd(i, k, -mat[k][i]);
		}
	}

	// Gaussian-Jordan ftw! :crab:
	for (int i = H - 1; i >= 0; i--) {
		for (int k = 0; k < i; k++) {
			mat[k][W - 1] -= mat[k][i] * mat[i][W - 1];
			mat[k][i] = 0;
		}
	}

	for (int i = 0; i < H; i++) {
		ans[i] = round(mat[i][W - 1]);
	}

	// Verify
	for (int i = 0; i < H; i++) {
		long long sum = 0;
		for (int k = 0; k < H; k++) {
			sum += origMat[i][k] * ans[k];
		}

		if (sum != origMat[i][W - 1]) return false;
	}

	return true;
}

void resetMat() {
	for (int y = 0; y < H; y++) {
		for (int x = 0; x < W; x++) {
			mat[y][x] = origMat[y][x];
		}
	}
}

void shuffleTillSolved() {
	for (int i = 0; i < H; i++) {
		for (int k = i + 1; k < H; k++) {
			resetMat();
			op1_exchangeRows(i, k);
			if (solve()) return;
		}
	}
}

int main()
{
	scanf("%d %d", &H, &W);

	for (int y = 0; y < H; y++) {
		for (int x = 0; x < W; x++) {
			long long inp;
			scanf("%lld", &inp);
			origMat[y][x] = inp;
		}
	}

	resetMat();
	if (!solve()) {
		shuffleTillSolved();
	}

	for (int i = 0; i < H; i++) {
		if (i != 0) printf(" ");
		printf("%lld", ans[i]);
	}
}