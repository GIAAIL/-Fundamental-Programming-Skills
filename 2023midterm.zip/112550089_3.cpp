#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void fromBin(char inp[], int out[]) {
	int k = 0;
	for (int i = strlen(inp) - 1; i >= 0; i--) {
		out[k] = inp[i] - '0';
		k++;
	}
}

int main()
{
	char a[256], b[256], c[256];
	gets_s(a); gets_s(b); gets_s(c);

	int A[256] = { 0 }, B[256] = { 0 }, C[256] = { 0 };
	fromBin(a, A); fromBin(b, B); fromBin(c, C);

	for (int i = 0; i < strlen(a); i++) {
		if (A[i] == 0) continue;
		for (int k = 0; k < strlen(b); k++) {
			C[i + k] += B[k];
		}
	}

	for (int i = 0; i < 255; i++) {
		C[i + 1] += C[i] / 2;
		C[i] %= 2;
	}

	int i = 255;
	while (C[i] == 0) {
		i--;
	}
	if (i < 0) printf("0");

	while (i >= 0) {
		printf("%c", '0' + C[i]);
		i--;
	}
	printf("\n");
}